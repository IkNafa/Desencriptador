package IkNafa.Desencriptador;

import IkNafa.Desencriptador.view.Ventana;

public class MainDesencriptar {
	public static void main(String[] args) {
		new Ventana();
	}
}
